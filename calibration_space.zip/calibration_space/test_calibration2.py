import numpy as np
import cv2
import math
# object_3d_points为点云的三维坐标，通过rviz中的select功能选取
# object_3d_points = np.array(([  4.2,-0.815, 0.429],
#                              [3.262, 0.420, 0.669],
#                              [4.189, 0.556, 0.390],
#                              [  3.8, 0.410, 0.650],
#                              [ 2.67, 0.390, 0.656]), dtype=np.double)
# # object_2d_point为与三维点云坐标对应的图像中的二维坐标，通过画图软件及点中后左下角的坐标确定。
# object_2d_point = np.array(([int(629)  , int(373)],
#                             [int(443)  , int(314)],
#                             [int(439)  , int(374)],
#                             [int(452)  , int(330)],
#                             [int(428)  , int(287)]), dtype=np.double)
object_3d_points = np.array(([3.55, 1.96 ,-0.51 ],
                             [4.40,-1.123,-0.146],
                             [3.53, 1.9  ,-1.19 ],
                             [4.39,-1.2  ,-0.81 ],
                             [7.71,-0.068,-1.103],
                             [6.92, 3.17 , 0.75 ]), dtype=np.double)
object_2d_point = np.array(([int(197)  , int(308)],
                            [int(944)  , int(193)],
                            [int(224)  , int(489)],
                            [int(953)  , int(358)],
                            [int(689)  , int( 23)],
                            [int(262)  , int( 85)]), dtype=np.double)
# camera_matrix = np.array(([566.0484654,    0. ,        527.98274577],
#                           [  0.       ,  566.707319 ,  401.15063122],
#                           [  0.       ,    0.      ,     1.        ]), dtype=np.double)
camera_matrix = np.array(([1083.4 ,    0., 604.58],
                          [   0.  , 1075 , 337.41],
                          [   0.  ,    0.,   1.  ]), dtype=np.double)
# dist_coefs = np.array([-0.02063467,  0.00416541, -0.00714799,  0.00248001,  0.00970291], dtype=np.double)# 求解相机位姿
dist_coefs = np.array([ -0.5702, 0.2705, -0.0014, 0.0040, 0.0000], dtype=np.double)# 求解相机位姿
############################################################################
found, rvec, tvec = cv2.solvePnP(object_3d_points, object_2d_point, camera_matrix, dist_coefs,flags=cv2.SOLVEPNP_SQPNP)
rotM = cv2.Rodrigues(rvec)[0]
print("----rotM=",rotM)
print("----tvec=",tvec)

# # 对第五个点进行验证
Out_matrix = np.concatenate((rotM, tvec), axis=1)
pixel = np.dot(camera_matrix, Out_matrix)

point_3D=np.array([7.71,-0.068,-1.103,1],dtype=np.double)
pixel1 = np.dot(pixel, point_3D)
print("-------point_3D=",point_3D)
pixel2 = pixel1/pixel1[2]
print("--------verified_point=",pixel2)

point_3D=np.array([7.71,-0.068,-1.103],dtype=np.double)
imgpts, jac = cv2.projectPoints(point_3D[0:3], rvec, tvec, camera_matrix, dist_coefs)
print("--------imgpts=",imgpts,"-----point_3D=",point_3D[0:3])

point_3D=np.array([4.39,-1.2  ,-0.81],dtype=np.double)
imgpts, jac = cv2.projectPoints(point_3D[0:3], rvec, tvec, camera_matrix, dist_coefs)
print("--------imgpts=",imgpts,"-----point_3D=",point_3D[0:3])

point_3D=np.array([6.915,3.17,0.75],dtype=np.double)
imgpts, jac = cv2.projectPoints(point_3D[0:3], rvec, tvec, camera_matrix, dist_coefs)
print("--------imgpts=",imgpts,"-----point_3D=",point_3D[0:3])



# ################################################################################
# pixel1 = np.dot(pixel, np.array([4.217, -0.86, -0.49, 1], dtype=np.double))
# print("-------pixel1=",pixel1)
# pixel2 = pixel1/pixel1[2]
# print("-----------point2=",pixel2)
# #注意：cv2.projectPoints函数的功能相当于以下四句代码的功能，都可以将三维点云投影至二维图像上，
# #获取三维点云在二维图像上对应的二维坐标：
# #Out_matrix = np.concatenate((rotM, tvec), axis=1)
# #pixel = np.dot(camera_matrix, Out_matrix)
# #pixel1 = np.dot(pixel, np.array([4.217, -0.86, -0.49, 1], dtype=np.double))
# #pixel2 = pixel1/pixel1[2]
# imgpts, jac = cv2.projectPoints(np.array([4.217, -0.86, -0.49], dtype=np.float32), rvec, tvec, camera_matrix, dist_coefs)
# print("-----imgpts=",imgpts)
# imgpts, jac = cv2.projectPoints(np.array([ 4.2,-0.815, 0.429], dtype=np.float32), rvec, tvec, camera_matrix, dist_coefs)
# print("-----imgpts2=",imgpts)


# # pixel1 = np.dot(pixel, np.array([4.224, -1.158, -0.47, 1], dtype=np.double))
# # print("-------pixel1=",pixel1)
# # pixel2 = pixel1/pixel1[2]
# # print("-----------point3=",pixel2)
# print("=================================================================")
# Out_matrix = np.concatenate((rotM, tvec), axis=1)
# print("-----------Out_matrix=",Out_matrix)
# pixel = np.dot(camera_matrix, Out_matrix)
# print("-----------pixel=",pixel,"--------pixel2=",camera_matrix@Out_matrix)
# point_3D=np.array([4.2,-0.815, 0.429,1],dtype=np.double)
# pixel1 = np.dot(pixel, np.array([2.67, 0.39, 0.656, 1], dtype=np.double))
# pixel1 = np.dot(pixel, point_3D)
# print("----********---point_3D=",point_3D)
# pixel2 = pixel1/pixel1[2]
# print("--------verified_point=",pixel2)
# print("===================test process==================================")
# camera_inv=np.linalg.inv(camera_matrix)
# img_2d_point = np.array(([int(629)  , int(373),int(1)]), dtype=np.double)
# print("--------------img_2d_point=",img_2d_point)
# print("--------------camera_inv@camera_matrix=",camera_inv@camera_matrix)
# left_data=camera_inv@img_2d_point
# right_data=Out_matrix@(point_3D.T)
# print("-----------pixel1=",pixel1)
# print("-----------left_data=",left_data)
# print("-----------Out_matrix.shape=",Out_matrix.shape,"---------point_3D.shape=",point_3D.shape)
# print("-----------right_data=",right_data)