import numpy as np
import cv2
import math
# object_3d_points为点云的三维坐标，通过rviz中的select功能选取
object_3d_points = np.array(([  4.2,-0.815, 0.429],
                             [3.262, 0.420, 0.669],
                             [4.189, 0.556, 0.390],
                             [  3.8, 0.410, 0.650],
                             [ 2.67, 0.390, 0.656]), dtype=np.double)
# object_2d_point为与三维点云坐标对应的图像中的二维坐标，通过画图软件及点中后左下角的坐标确定。
object_2d_point = np.array(([int(629)  , int(373)],
                            [int(443)  , int(314)],
                            [int(439)  , int(374)],
                            [int(452)  , int(330)],
                            [int(428)  , int(287)]), dtype=np.double)
# object_3d_points = np.array(([  4.2,-0.815, 0.429],
#                              [3.262, 0.420, 0.669],
#                              [4.189, 0.556, 0.390],
#                              [  3.8, 0.410, 0.650]), dtype=np.double)
# object_2d_point = np.array(([int(629)  , int(373)],
#                             [int(443)  , int(314)],
#                             [int(439)  , int(374)],
#                             [int(452)  , int(330)]), dtype=np.double)
#camera_matrix = np.array(([1338.0, 0, 623.5],
#                         [0, 1338.4, 875.4],
#                         [0, 0, 1.0]), 
camera_matrix = np.array(([566.0484654,    0. ,        527.98274577],
                          [  0.       ,  566.707319 ,  401.15063122],
                          [  0.       ,    0.      ,     1.        ]), dtype=np.double)
#dist_coefs = np.array([ 0.17698838, -1.02382813,  0.00563977,  0.00279505, 1.70259665], dtype=np.double)# 求解相机位姿
dist_coefs = np.array([-0.02063467,  0.00416541, -0.00714799,  0.00248001,  0.00970291], dtype=np.double)# 求解相机位姿
############################################################################
found, rvec, tvec = cv2.solvePnP(object_3d_points, object_2d_point, camera_matrix, dist_coefs,flags=cv2.SOLVEPNP_SQPNP)
rotM = cv2.Rodrigues(rvec)[0]
print("----rotM=",rotM)
print("----tvec=",tvec)
camera_postion = -np.matrix(rotM).T * np.matrix(tvec)
print("---------camera_postion.T=",camera_postion.T)
#################################################################################
#验证根据博客http://www.cnblogs.com/singlex/p/pose_estimation_1.html提供方法求解相机位姿
#计算相机坐标系的三轴旋转欧拉角，旋转后可以转出世界坐标系。旋转顺序z,y,x
thetaZ = math.atan2(rotM[1, 0], rotM[0, 0])*180.0/math.pi
# thetaZ = math.atan2(rotM[2, 0], rotM[0, 0])*180.0/math.pi
thetaY = math.atan2(-1.0*rotM[2, 0], math.sqrt(rotM[2, 1]**2 + rotM[2, 2]**2))*180.0/math.pi
thetaX = math.atan2(rotM[2, 1], rotM[2, 2])*180.0/math.pi# 相机坐标系下值
x = tvec[0]
y = tvec[1]
z = tvec[2]
# 位移向量x,y,z根据thetaZ，thetaY，thetaX进行三次旋转，实现相机坐标原点在世界坐标系统中的变换。
def RotateByZ(Cx, Cy, thetaZ):
    rz = thetaZ*math.pi/180.0
    outX = math.cos(rz)*Cx - math.sin(rz)*Cy
    outY = math.sin(rz)*Cx + math.cos(rz)*Cy
    return outX, outY
def RotateByY(Cx, Cz, thetaY):
    ry = thetaY*math.pi/180.0
    outZ = math.cos(ry)*Cz - math.sin(ry)*Cx
    outX = math.sin(ry)*Cz + math.cos(ry)*Cx
    return outX, outZ
def RotateByX(Cy, Cz, thetaX):
    rx = thetaX*math.pi/180.0
    outY = math.cos(rx)*Cy - math.sin(rx)*Cz
    outZ = math.sin(rx)*Cy + math.cos(rx)*Cz
    return outY, outZ
(x, y) = RotateByZ(x, y, -1.0*thetaZ)
(x, z) = RotateByY(x, z, -1.0*thetaY)
(y, z) = RotateByX(y, z, -1.0*thetaX)
Cx = x*-1
Cy = y*-1
Cz = z*-1

# 输出相机位置
print("------Position of camera is:",Cx, Cy, Cz) # is equal to the camera_postion
# 输出相机旋转角
print("------rotation angle is:",thetaX, thetaY, thetaZ)
# 对第五个点进行验证
Out_matrix = np.concatenate((rotM, tvec), axis=1)
pixel = np.dot(camera_matrix, Out_matrix)
pixel1 = np.dot(pixel, np.array([2.67, 0.39, 0.656, 1], dtype=np.double))
print("-------pixel1=",pixel1)
pixel2 = pixel1/pixel1[2]
print(pixel2)
# cv2.circle(img, (int(pixel2[0]), int(pixel2[1])), 12, (255, 0, 255), 2)
# cv2.imwrite("result.jpg",img)
################################################################################
pixel1 = np.dot(pixel, np.array([4.217, -0.86, -0.49, 1], dtype=np.double))
print("-------pixel1=",pixel1)
pixel2 = pixel1/pixel1[2]
print("-----------point2=",pixel2)
#注意：cv2.projectPoints函数的功能相当于以下四句代码的功能，都可以将三维点云投影至二维图像上，
#获取三维点云在二维图像上对应的二维坐标：
#Out_matrix = np.concatenate((rotM, tvec), axis=1)
#pixel = np.dot(camera_matrix, Out_matrix)
#pixel1 = np.dot(pixel, np.array([4.217, -0.86, -0.49, 1], dtype=np.double))
#pixel2 = pixel1/pixel1[2]
imgpts, jac = cv2.projectPoints(np.array([4.217, -0.86, -0.49], dtype=np.float32), rvec, tvec, camera_matrix, dist_coefs)
print("-----imgpts=",imgpts)

pixel1 = np.dot(pixel, np.array([4.224, -1.158, -0.47, 1], dtype=np.double))
print("-------pixel1=",pixel1)
pixel2 = pixel1/pixel1[2]
print("-----------point3=",pixel2)

