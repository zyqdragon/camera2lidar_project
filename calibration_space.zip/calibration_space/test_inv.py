import numpy as np
 
# 创建一个方阵
matrix = np.array([[4, 7],
                   [2, 6]])
 
# 使用numpy.linalg.inv()计算逆矩阵
inverse_matrix = np.linalg.inv(matrix)
 
print("原矩阵:")
print(matrix)
 
print("逆矩阵:")
print(inverse_matrix@matrix)

camera_matrix = np.array(([566.0484654,    0. ,        527.98274577],
                          [  0.       ,  566.707319 ,  401.15063122],
                          [  0.       ,    0.      ,     1.        ]), dtype=np.double)
                          
input_vec = np.array([[4,2,1]])
                          
camera_inv=np.linalg.inv(camera_matrix)
print("----------camera_inv=",camera_inv)

print("----------camera_inv@camera_matrix=",camera_inv@camera_matrix)

print("----------camera_inv@camera_matrix=",camera_matrix@camera_inv)

print("---------input_vect=",input_vec.T)
print("---------camera_inv@input_vect=",camera_inv@(input_vec.T))
 
