import rosbag
import cv2
from cv_bridge import CvBridge
 
print("----------tp1--------------")
image_path = './image_files2/'
# bag_path = './image_pcd.bag'
print("----------tp2--------------")
bag_path = './camera_lidar_2024.bag'
# topic_name = '/yolov8/detection_image'
topic_name = '/hik1/hik_cam_node/hik_camera1'
print("----------tp3--------------")

bridge = CvBridge()
with rosbag.Bag(bag_path, 'r') as bag:
  print("----------tp4--------------")
  for topic,msg,t in bag.read_messages():
    # print("----------tp5--------------")
    if topic == topic_name:
      cv_image = bridge.imgmsg_to_cv2(msg,"bgr8")
      print("----------tp6--------------")
      timestr = "%.6f" %  msg.header.stamp.to_sec()
      image_name = timestr+ ".jpg"
      cv2.imwrite(image_path+image_name, cv_image)
      
#https://blog.csdn.net/qq_42702222/article/details/129429650
