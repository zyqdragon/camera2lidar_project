import rosbag
import cv2
from cv_bridge import CvBridge
 
image_path = './image_files/'
bag_path = './image_pcd.bag'
topic_name = '/yolov8/detection_image'
 
bridge = CvBridge()
with rosbag.Bag(bag_path, 'r') as bag:
  for topic,msg,t in bag.read_messages():
    if topic == topic_name:
      cv_image = bridge.imgmsg_to_cv2(msg,"bgr8")
      timestr = "%.6f" %  msg.header.stamp.to_sec()
      image_name = timestr+ ".jpg"
      cv2.imwrite(image_path+image_name, cv_image)
      
#https://blog.csdn.net/qq_42702222/article/details/129429650
