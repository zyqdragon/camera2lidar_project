import numpy as np
import open3d as o3d
from copy import deepcopy
import os

pcd_path="pcd_subfiles"
# 读取点云文件加中文件名
files = os.listdir(pcd_path)
pcd_whole=o3d.geometry.PointCloud()   # original point clouds


for f in files:
    print("------file path is:",pcd_path +"/"+ f)
    pointcloud = o3d.io.read_point_cloud(pcd_path +"/"+ f)
    # pointcloud.paint_uniform_color([1, 0, 0])
    pcd_whole=pcd_whole+pointcloud


bbox = o3d.geometry.AxisAlignedBoundingBox(min_bound=(0,-8,-6),max_bound=(11,8,3)) # 点云裁剪
pcd_whole = pcd_whole.crop(bbox)
o3d.io.write_point_cloud("whole_pcd.pcd", pcd_whole)
FOR1 = o3d.geometry.TriangleMesh.create_coordinate_frame(size=1, origin=[0, 0, 0])
vis = o3d.visualization.Visualizer()
# #vis.create_window(window_name='shared_memory_display', width=800, height=600)
vis.create_window(window_name='shared_memory_display')
render_option: o3d.visualization.RenderOption = vis.get_render_option() 
render_option.background_color = np.array([0, 0, 0]) 
render_option.point_size = 1.0 
vis.add_geometry(pcd_whole) 
vis.add_geometry(FOR1) 
vis.run()
vis.destory_window()




# ###############################################################################################
# FOR1 = o3d.geometry.TriangleMesh.create_coordinate_frame(size=2, origin=[0, 0, 0])
# FOR_base= copy.deepcopy(FOR1)
# # FOR_base is transformed according to the same parameter with the pointcloud_preprocess function
# R = FOR_base.get_rotation_matrix_from_xyz((0,-np.pi/8,0))#绕y轴旋转90°\
# FOR_base.rotate(R,center=(0,0,0))#旋转点位于x=20处，若不指定则默认为原始点云质心。
# R = FOR_base.get_rotation_matrix_from_xyz((0,0,np.pi/5))#绕z轴旋转90°
# FOR_base.rotate(R,center=(0,0,0))#旋转点位于x=20处，若不指定则默认为原始点云质心。

# # FOR1.translate((0,0,-1), relative=True)
# # FOR1.translate((1,1,0), relative=True)
# pcd=o3d.geometry.PointCloud()   # original point clouds
# pcd2=o3d.geometry.PointCloud()   # temp point clouds
# pcd3=o3d.geometry.PointCloud()   # filtered point clouds
# # dig_body=o3d.geometry.PointCloud()   # filtered point clouds
# mesh_pcd=o3d.geometry.PointCloud()
 

# # ##################################end of earth_surface################################
# vis = o3d.visualization.Visualizer()
# to_reset = True
# #vis.create_window(window_name='shared_memory_display', width=800, height=600)
# vis.create_window(window_name='shared_memory_display')
# render_option: o3d.visualization.RenderOption = vis.get_render_option() 
# render_option.background_color = np.array([0, 0, 0]) 
# render_option.show_coordinate_frame = True
# render_option.point_size = 3.0 
# mesh_pcd.paint_uniform_color([0,1,1]) #设置点云颜色为红色

# # vis.add_geometry(FOR1)
# vis.add_geometry(FOR_base)
# # vis.add_geometry(pcd)
# vis.add_geometry(mesh_pcd) 
# vis.add_geometry(lines_pcd_h) 
# FOA_exca =  o3d.geometry.TriangleMesh.create_coordinate_frame(size=3, origin=[0, 0, 0])
# vis.add_geometry(FOA_exca)


# ###################end of excavator ####################################3
# pcd2.paint_uniform_color([1,0,1]) #设置点云颜色为红色

#    if to_reset:
#         vis.reset_view_point(True)
#         to_reset = False
#    # time.sleep(0.0000002)
#    vis.poll_events()
#    vis.update_renderer()
# existing_shm.close()
# existing_shm.unlink()
