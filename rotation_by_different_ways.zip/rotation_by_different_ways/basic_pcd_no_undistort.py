import os
import open3d as o3d
import numpy as np
from copy import deepcopy
import time
import cv2
 
# 设置文件夹路径
folder_path ="pcd_files_r1"

rotation_angle=0
rotation_speed=0

# map_pcd=o3d.io.read_point_cloud("./pcd_files/"+"1713424380.599298000.pcd")
map_pcd = o3d.geometry.PointCloud()

axis_basic = o3d.geometry.TriangleMesh.create_coordinate_frame(size=1, origin=[0,0,0])
axis_lidar = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.5, origin=[0,0,0])


R = axis_lidar.get_rotation_matrix_from_xyz((0,0,0.0079))
axis_lidar.rotate(R, center=(0,0,0))
R = axis_lidar.get_rotation_matrix_from_xyz((0,0.3334,0))
axis_lidar.rotate(R, center=(0,0,0))
R = axis_lidar.get_rotation_matrix_from_xyz((-0.0170,0,0))
axis_lidar.rotate(R, center=(0,0,0))
axis_lidar.translate((1.7509,1.1748,1.9952+1.57),relative=True)

pcd_name="1714444449.499606609.pcd" 
pcd = o3d.io.read_point_cloud(pcd_name)
print("-------pcd=",pcd)
# 输出所有文件名

pcd0 = o3d.geometry.PointCloud()
pcd1 = o3d.geometry.PointCloud()
pcd2 = o3d.geometry.PointCloud()
pcd3 = o3d.geometry.PointCloud()
pcd4 = o3d.geometry.PointCloud()
pcd5 = o3d.geometry.PointCloud()
pcd6 = o3d.geometry.PointCloud()
pcd7 = o3d.geometry.PointCloud()
pcd8 = o3d.geometry.PointCloud()
pcd9 = o3d.geometry.PointCloud()

print(pcd_name)	
file=open('data_record_r1.txt', 'r')
line = file.readline()
while line:
    # print(line.strip())  # 去掉尾部的换行符
	splitted_list = line.split(',')
	temp1=splitted_list[0]
   	# print(splitted_list,"-----0-18=",temp1[0:15],"----pcd_name=",pcd_name[0:15])
   	# rangle=float(splitted_list[1])
	if(abs(float(temp1[0:15])-float(pcd_name[0:15]))<0.002):
		rotation_angle=float(splitted_list[1])
		rotation_speed=float(splitted_list[2])
		print("-----the matched time is:",temp1,"----rangle=",rotation_angle,"----rspeed=",rotation_speed)
	line = file.readline()
   	# rotation_angle=rangle
   	# print("--------rotation_angle=",rotation_angle)
file.close()
print("--------rotation_angle3=",rotation_angle,"--------rotation_speed=",rotation_speed)
	
R = pcd.get_rotation_matrix_from_xyz((0,0,0.0079))
pcd.rotate(R, center=(0,0,0))
R = pcd.get_rotation_matrix_from_xyz((0,0.3334,0))
pcd.rotate(R, center=(0,0,0))
R = pcd.get_rotation_matrix_from_xyz((-0.0170,0,0))
pcd.rotate(R, center=(0,0,0))
pcd.translate((1.7509,1.1748,(1.9952+1.57)),relative=True)
# R = pcd.get_rotation_matrix_from_xyz((0,0,-3.9*np.pi/180))  # rotation by rotation encoder
# R = pcd.get_rotation_matrix_from_xyz((0,0,rotation_angle*np.pi/180))  # rotation by rotation encoder
# pcd.rotate(R, center=(0,0,0))

# pcd_points=np.array(pcd.points)
# pcd0.points = o3d.utility.Vector3dVector(pcd_points[2400*0:2400*1])
# pcd1.points = o3d.utility.Vector3dVector(pcd_points[2400*1:2400*2])
# pcd2.points = o3d.utility.Vector3dVector(pcd_points[2400*2:2400*3])
# pcd3.points = o3d.utility.Vector3dVector(pcd_points[2400*3:2400*4])
# pcd4.points = o3d.utility.Vector3dVector(pcd_points[2400*4:2400*5])
# pcd5.points = o3d.utility.Vector3dVector(pcd_points[2400*5:2400*6])
# pcd6.points = o3d.utility.Vector3dVector(pcd_points[2400*6:2400*7])
# pcd7.points = o3d.utility.Vector3dVector(pcd_points[2400*7:2400*8])
# pcd8.points = o3d.utility.Vector3dVector(pcd_points[2400*8:2400*9])
# pcd9.points = o3d.utility.Vector3dVector(pcd_points[2400*9:2400*10])

# print("----------------------len of pointcloud=",len(pcd_points),"---------len of pointcloud9=",len(pcd_points[2400*9:2400*10+300]),"---------len of pointcloud8=",len(pcd_points[2400*8:2400*9]))

# rangle0=(rotation_angle-(rotation_speed*9/100))
# rangle1=(rotation_angle-(rotation_speed*8/100))
# rangle2=(rotation_angle-(rotation_speed*7/100))
# rangle3=(rotation_angle-(rotation_speed*6/100))
# rangle4=(rotation_angle-(rotation_speed*5/100))
# rangle5=(rotation_angle-(rotation_speed*4/100))
# rangle6=(rotation_angle-(rotation_speed*3/100))
# rangle7=(rotation_angle-(rotation_speed*2/100))
# rangle8=(rotation_angle-(rotation_speed*1/100))
# rangle9=(rotation_angle-(rotation_speed*0/100))

# print("---r9=",rangle9,"---r8=",rangle8,"---r7=",rangle7,"---r6=",rangle6,"---r5=",rangle5,"---r4=",rangle4,"---r3=",rangle3,"---r2=",rangle2,"---r1=",rangle1,"---r0=",rangle0)
# bbox = o3d.geometry.AxisAlignedBoundingBox(min_bound=(0,-5,-3),max_bound=(16,5,9)) # 点云裁剪
# pcd0 = pcd0.crop(bbox)
# pcd1 = pcd1.crop(bbox)
# pcd2 = pcd2.crop(bbox)
# pcd3 = pcd3.crop(bbox)
# pcd4 = pcd4.crop(bbox)
# pcd5 = pcd5.crop(bbox)
# pcd6 = pcd6.crop(bbox)
# pcd7 = pcd7.crop(bbox)
# pcd8 = pcd8.crop(bbox)
# pcd9 = pcd9.crop(bbox)

# R = pcd0.get_rotation_matrix_from_xyz((0,0,rangle0*np.pi/180))  # rotation by rotation encoder
# pcd0.rotate(R, center=(0,0,0))
# R = pcd1.get_rotation_matrix_from_xyz((0,0,rangle1*np.pi/180))  # rotation by rotation encoder
# pcd1.rotate(R, center=(0,0,0))
# R = pcd2.get_rotation_matrix_from_xyz((0,0,rangle2*np.pi/180))  # rotation by rotation encoder
# pcd2.rotate(R, center=(0,0,0))
# R = pcd3.get_rotation_matrix_from_xyz((0,0,rangle3*np.pi/180))  # rotation by rotation encoder
# pcd3.rotate(R, center=(0,0,0))
# R = pcd4.get_rotation_matrix_from_xyz((0,0,rangle4*np.pi/180))  # rotation by rotation encoder
# pcd4.rotate(R, center=(0,0,0))
# R = pcd5.get_rotation_matrix_from_xyz((0,0,rangle5*np.pi/180))  # rotation by rotation encoder
# pcd5.rotate(R, center=(0,0,0))
# R = pcd6.get_rotation_matrix_from_xyz((0,0,rangle6*np.pi/180))  # rotation by rotation encoder
# pcd6.rotate(R, center=(0,0,0))
# R = pcd7.get_rotation_matrix_from_xyz((0,0,rangle7*np.pi/180))  # rotation by rotation encoder
# pcd7.rotate(R, center=(0,0,0))
# R = pcd8.get_rotation_matrix_from_xyz((0,0,rangle8*np.pi/180))  # rotation by rotation encoder
# pcd8.rotate(R, center=(0,0,0))
# R = pcd9.get_rotation_matrix_from_xyz((0,0,rangle9*np.pi/180))  # rotation by rotation encoder
# pcd9.rotate(R, center=(0,0,0))

# map_pcd=map_pcd+pcd0+pcd1+pcd2+pcd3+pcd4+pcd5+pcd6+pcd7+pcd8+pcd9


bbox = o3d.geometry.AxisAlignedBoundingBox(min_bound=(0,-5,-1),max_bound=(11,5,6)) # 点云裁剪
pcd = pcd.crop(bbox)

vis = o3d.visualization.Visualizer()
vis.create_window()
opt = vis.get_render_option()
opt.background_color = np.asarray([0, 0, 0]) 
opt.point_size = 0.5
vis.add_geometry(axis_basic)
vis.add_geometry(axis_lidar)
vis.add_geometry(pcd)
# vis.add_geometry(map_pcd)
vis.run()
vis.destroy_window()
# o3d.io.write_point_cloud("map_with_undistort_r1.pcd",map_pcd)
