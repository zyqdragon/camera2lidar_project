import numpy as np
import open3d as o3d
from copy import deepcopy

print(np.sin(30*np.pi/180))

angle_X=60*np.pi/180
angle_Y=30*np.pi/180
angle_Z=60*np.pi/180

Xrot = np.array([[1,0,0],
    [0,np.cos(angle_X), -np.sin(angle_X)],
    [0,np.sin(angle_X), np.cos(angle_X)]])

Yrot = np.array([[np.cos(angle_Y), 0,np.sin(angle_Y)],
      [0,1,0],
    [-np.sin(angle_Y), 0, np.cos(angle_Y)]])

Zrot = np.array([[np.cos(angle_Z), -np.sin(angle_Z), 0],
    [np.sin(angle_Z), np.cos(angle_Z), 0],
    [0, 0, 1]])

print("------Zrot=",Zrot)

# pcd = o3d.io.read_point_cloud("./1714444449.499606609.pcd")
pcd = o3d.io.read_point_cloud("./pcd_whole.pcd")
axis_basic = o3d.geometry.TriangleMesh.create_coordinate_frame(size=1, origin=[0,0,0])
pcd_basic=deepcopy(pcd)
R = pcd.get_rotation_matrix_from_xyz((0,0,np.pi/3))
pcd.rotate(R, center=(0,0,0))

pcd_points=np.array(pcd_basic.points)
print("-----pcd_points=",pcd_points.shape)

rot_result=Yrot@Zrot@(pcd_points.T)
# rot_result=Zrot@(pcd_points.T)
print("-----rot_result=",rot_result.shape)
matrix_pcd= o3d.geometry.PointCloud()
# pcd_points=np.array(pcd.points)
matrix_pcd.points = o3d.utility.Vector3dVector((rot_result.T))

vis = o3d.visualization.Visualizer()
vis.create_window()
opt = vis.get_render_option()
opt.background_color = np.asarray([0, 0, 0]) 
opt.point_size = 1.0
vis.add_geometry(axis_basic)
pcd_basic.paint_uniform_color([1,1,0]) #设置点云颜色为红色
pcd.paint_uniform_color([0,1,0]) #设置点云颜色为红色
vis.add_geometry(pcd)
vis.add_geometry(pcd_basic)
matrix_pcd.paint_uniform_color([0,1,1]) #设置点云颜色为红色
vis.add_geometry(matrix_pcd)
# vis.add_geometry(axis_1)
vis.run()
vis.destroy_window()


# pcd1.points = o3d.utility.Vector3dVector(pcd_points[2400*1:2400*2])
# axis_1 = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.5, origin=[0,0,0])
# axis_1.translate((0,0,1),relative=True)
# # R = axis_1.get_rotation_matrix_from_xyz((np.pi/6,0,0))
# R = axis_1.get_rotation_matrix_from_xyz((0,0,np.pi/6))
# # axis_1.rotate(R, center=(0,0,1))
# axis_1.rotate(R, center=(0,0,0))