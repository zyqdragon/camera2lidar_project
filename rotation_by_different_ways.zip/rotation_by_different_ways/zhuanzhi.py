import numpy as np
 
# 创建一个二维数组（矩阵）
matrix = np.array([[1, 2, 3], [4, 5, 6]])
 
# 使用.T属性进行转置
transposed_matrix = matrix.T
 
# 或者使用numpy.transpose()函数进行转置
transposed_matrix = np.transpose(matrix)

print("------matrix=",matrix)
print("------transposed_matrix=",transposed_matrix)