import numpy as np
import open3d as o3d
from copy import deepcopy
import os

pcd_path="pcd_subfiles"
# 读取点云文件加中文件名
files = os.listdir(pcd_path)
pcd_whole=o3d.geometry.PointCloud()   # original point clouds


for f in files:
    print("------file path is:",pcd_path +"/"+ f)
    pointcloud = o3d.io.read_point_cloud(pcd_path +"/"+ f)
    # pointcloud.paint_uniform_color([1, 0, 0])
    pcd_whole=pcd_whole+pointcloud


bbox = o3d.geometry.AxisAlignedBoundingBox(min_bound=(0,-8,-6),max_bound=(11,8,3)) # 点云裁剪
pcd_whole = pcd_whole.crop(bbox)
o3d.io.write_point_cloud("whole_pcd.pcd", pcd_whole)
FOR1 = o3d.geometry.TriangleMesh.create_coordinate_frame(size=1, origin=[0, 0, 0])
vis = o3d.visualization.Visualizer()
# #vis.create_window(window_name='shared_memory_display', width=800, height=600)
vis.create_window(window_name='shared_memory_display')
render_option: o3d.visualization.RenderOption = vis.get_render_option() 
render_option.background_color = np.array([0, 0, 0]) 
render_option.point_size = 1.0 
vis.add_geometry(pcd_whole) 
vis.add_geometry(FOR1) 
vis.run()
vis.destory_window()
