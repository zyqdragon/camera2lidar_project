import numpy as np
import cv2
import math
# object_3d_points为点云的三维坐标，通过rviz中的select功能选取
object_3d_points = np.array(([  4.2,-0.815, 0.429],
                             [3.262, 0.420, 0.669],
                             [4.189, 0.556, 0.390],
                             [  3.8, 0.410, 0.650],
                             [ 2.67, 0.390, 0.656]), dtype=np.double)
# object_2d_point为与三维点云坐标对应的图像中的二维坐标，通过画图软件及点中后左下角的坐标确定。
object_2d_point = np.array(([int(629)  , int(373)],
                            [int(443)  , int(314)],
                            [int(439)  , int(374)],
                            [int(452)  , int(330)],
                            [int(428)  , int(287)]), dtype=np.double)
# object_3d_points = np.array(([  4.2,-0.815, 0.429],
#                              [3.262, 0.420, 0.669],
#                              [4.189, 0.556, 0.390],
#                              [  3.8, 0.410, 0.650]), dtype=np.double)
# object_2d_point = np.array(([int(629)  , int(373)],
#                             [int(443)  , int(314)],
#                             [int(439)  , int(374)],
#                             [int(452)  , int(330)]), dtype=np.double)
#camera_matrix = np.array(([1338.0, 0, 623.5],
#                         [0, 1338.4, 875.4],
#                         [0, 0, 1.0]), 
camera_matrix = np.array(([566.0484654,    0. ,        527.98274577],
                          [  0.       ,  566.707319 ,  401.15063122],
                          [  0.       ,    0.      ,     1.        ]), dtype=np.double)
#dist_coefs = np.array([ 0.17698838, -1.02382813,  0.00563977,  0.00279505, 1.70259665], dtype=np.double)# 求解相机位姿
dist_coefs = np.array([-0.02063467,  0.00416541, -0.00714799,  0.00248001,  0.00970291], dtype=np.double)# 求解相机位姿
############################################################################
found, rvec, tvec = cv2.solvePnP(object_3d_points, object_2d_point, camera_matrix, dist_coefs,flags=cv2.SOLVEPNP_SQPNP)
rotM = cv2.Rodrigues(rvec)[0]
print("----rotM=",rotM)
print("----tvec=",tvec)
camera_postion = -np.matrix(rotM).T * np.matrix(tvec)
print("---------camera_postion.T=",camera_postion.T)
#################################################################################
imgpts, jac = cv2.projectPoints(np.array([ 4.2,-0.815, 0.429], dtype=np.float32), rvec, tvec, camera_matrix, dist_coefs)
print("-----imgpts=",imgpts)
