import numpy as np
import cv2
import math
# object_3d_points为点云的三维坐标，通过rviz中的select功能选取
# object_3d_points = np.array(([6.131, -2.885,  0.222],
#                              [6.224, -4.143, -0.903],
#                              [8.098,  1.310, -0.18 ],
#                              [9.816, -0.511,  1.256]), dtype=np.double)
# # object_2d_point为与三维点云坐标对应的图像中的二维坐标，通过画图软件及点中后左下角的坐标确定。
# object_2d_point = np.array(([int(1095)  , int(153)],
#                             [int(1210)  , int(317)],
#                             [int(509)  , int(185)],
#                             [int(723)  , int(37)]), dtype=np.double)
object_3d_points = np.array(([6.131, -2.885,  0.222],
                             [6.224, -4.143, -0.903],
                             [8.098,  1.310, -0.18 ],
                             [9.816, -0.511,  1.256],
                             [6.986, -0.918,  0.54 ],
                             [7.277,  0.381, -0.278]), dtype=np.double)
# object_2d_point为与三维点云坐标对应的图像中的二维坐标，通过画图软件及点中后左下角的坐标确定。
object_2d_point = np.array(([int(1095)  , int(153)],
                            [int(1210)  , int(317)],
                            [int(509)  , int(185)],
                            [int(723)  , int(37)],
                            [int(808)  , int(87)],
                            [int(622)  , int(198)]), dtype=np.double)

#camera_matrix = np.array(([1338.0, 0, 623.5],
#                         [0, 1338.4, 875.4],
#                         [0, 0, 1.0]), 
camera_matrix = np.array(([1083.4     ,    0. ,        604.58],
                          [  0.       ,  1075 ,        337.41],
                          [  0.       ,    0.      ,     1.        ]), dtype=np.double)
#dist_coefs = np.array([ 0.17698838, -1.02382813,  0.00563977,  0.00279505, 1.70259665], dtype=np.double)# 求解相机位姿
dist_coefs = np.array([ -0.5702,  0.2705, -0.0014,   0.0040,  0.0000], dtype=np.double)# 求解相机位姿
############################################################################
found, rvec, tvec = cv2.solvePnP(object_3d_points, object_2d_point, camera_matrix, dist_coefs,flags=cv2.SOLVEPNP_SQPNP)
rotM = cv2.Rodrigues(rvec)[0]
print("----rotM=",rotM)
print("----tvec=",tvec)
camera_postion = -np.matrix(rotM).T * np.matrix(tvec)
print("---------camera_postion.T=",camera_postion.T)
###################################### EPNP ##############################################################
# found, rvec, tvec = cv2.solvePnP(object_3d_points, object_2d_point, camera_matrix, dist_coefs,flags=cv2.SOLVEPNP_EPNP)
# rotM = cv2.Rodrigues(rvec)[0]
# print("----rotM=",rotM)
# print("----tvec=",tvec)
# camera_postion = -np.matrix(rotM).T * np.matrix(tvec)
# print("---------camera_postion.T=",camera_postion.T)
#################################################################################
imgpts, jac = cv2.projectPoints(np.array([6.131, -2.885,  0.222], dtype=np.float32), rvec, tvec, camera_matrix, dist_coefs)
print("-----imgpts=",imgpts)
imgpts, jac = cv2.projectPoints(np.array([6.224, -4.143, -0.903], dtype=np.float32), rvec, tvec, camera_matrix, dist_coefs)
print("-----imgpts=",imgpts)
imgpts, jac = cv2.projectPoints(np.array([8.098,  1.310, -0.18 ], dtype=np.float32), rvec, tvec, camera_matrix, dist_coefs)
print("-----imgpts=",imgpts)
imgpts, jac = cv2.projectPoints(np.array([9.816, -0.511,  1.256], dtype=np.float32), rvec, tvec, camera_matrix, dist_coefs)
print("-----imgpts=",imgpts)
imgpts, jac = cv2.projectPoints(np.array([6.986, -0.918,  0.54], dtype=np.float32), rvec, tvec, camera_matrix, dist_coefs)
print("-----imgpts=",imgpts)
imgpts, jac = cv2.projectPoints(np.array([7.277,  0.381, -0.278], dtype=np.float32), rvec, tvec, camera_matrix, dist_coefs)
print("-----imgpts=",imgpts)